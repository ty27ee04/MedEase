using Microsoft.AspNetCore.Mvc;
using HealthTech.Services;

namespace HealthTech.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AppointmentsController : ControllerBase
    {
        [HttpGet]
        public ActionResult<List<AppointmentModel>> GetAllAppointments()
        {
            try
            {
                var appointments = DatabaseManager.GetInstance().GetAllAppointments();
                return Ok(appointments);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpGet("upcoming")]
        public ActionResult<List<AppointmentModel>> GetUpcomingAppointments()
        {
            try
            {
                var appointments = DatabaseManager.GetInstance().GetUpcomingAppointments();
                return Ok(appointments);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpGet("{id}")]
        public ActionResult<AppointmentModel> GetAppointmentById(int id)
        {
            try
            {
                var appointments = DatabaseManager.GetInstance().GetAllAppointments();
                var appointment = appointments.FirstOrDefault(a => a.AppointmentID == id);
                if (appointment == null)
                    return NotFound();
                return Ok(appointment);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpPost]
        public ActionResult<object> CreateAppointment([FromBody] AppointmentModel appointment)
        {
            try
            {
                DatabaseManager.GetInstance().AddAppointment(appointment);
                return Ok(new { id = appointment.AppointmentID, message = "Appointment created successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpPut("{id}")]
        public ActionResult UpdateAppointment(int id, [FromBody] AppointmentModel appointment)
        {
            try
            {
                appointment.AppointmentID = id;
                DatabaseManager.GetInstance().UpdateAppointment(appointment);
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpDelete("{id}")]
        public ActionResult DeleteAppointment(int id)
        {
            try
            {
                DatabaseManager.GetInstance().DeleteAppointment(id);
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpGet("doctor/{doctorId}/available-slots")]
        public ActionResult<List<TimeSlot>> GetAvailableTimeSlots(
            int doctorId, 
            [FromQuery] DateTime date, 
            [FromQuery] int slotDuration = 30)
        {
            try
            {
                var slots = DatabaseManager.GetInstance()
                    .GetAvailableTimeSlots(doctorId, date, slotDuration);
                return Ok(slots);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpGet("doctor/{doctorId}")]
        public ActionResult<List<AppointmentModel>> GetAppointmentsByDoctor(int doctorId)
        {
            try
            {
                var appointments = DatabaseManager.GetInstance().GetAllAppointments()
                    .Where(a => a.DoctorID == doctorId).ToList();
                return Ok(appointments);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpGet("patient/{patientId}")]
        public ActionResult<List<AppointmentModel>> GetAppointmentsByPatient(int patientId)
        {
            try
            {
                var appointments = DatabaseManager.GetInstance().GetAllAppointments()
                    .Where(a => a.PatientID == patientId).ToList();
                return Ok(appointments);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }
    }
}
