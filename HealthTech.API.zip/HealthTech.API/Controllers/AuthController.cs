using Microsoft.AspNetCore.Mvc;
using HealthTech.Services;
using MySql.Data.MySqlClient;

namespace HealthTech.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        [HttpPost("login")]
        public ActionResult<LoginResponse> Login([FromBody] LoginRequest request)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(request.Email) || string.IsNullOrWhiteSpace(request.Password))
                {
                    return Ok(new LoginResponse 
                    { 
                        Success = false, 
                        Message = "Email and password are required" 
                    });
                }

                var user = DatabaseManager.GetInstance().AuthenticateUser(request.Email, request.Password);
                
                if (user != null)
                {
                    // Don't send password back to client
                    user.Password = "";
                    
                    return Ok(new LoginResponse 
                    { 
                        Success = true, 
                        Message = "Login successful", 
                        User = user 
                    });
                }
                else
                {
                    return Ok(new LoginResponse 
                    { 
                        Success = false, 
                        Message = "Invalid email or password" 
                    });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new LoginResponse 
                { 
                    Success = false, 
                    Message = "Server error: " + ex.Message 
                });
            }
        }

        [HttpPost("register")]
        public ActionResult<LoginResponse> Register([FromBody] RegisterRequest request)
        {
            try
            {
                // Validate required fields
                if (string.IsNullOrWhiteSpace(request.Name))
                {
                    return Ok(new LoginResponse { Success = false, Message = "Name is required" });
                }
                
                if (string.IsNullOrWhiteSpace(request.Email))
                {
                    return Ok(new LoginResponse { Success = false, Message = "Email is required" });
                }
                
                if (string.IsNullOrWhiteSpace(request.Password))
                {
                    return Ok(new LoginResponse { Success = false, Message = "Password is required" });
                }
                
                if (string.IsNullOrWhiteSpace(request.Role))
                {
                    return Ok(new LoginResponse { Success = false, Message = "Role is required" });
                }
                
                // Validate doctor-specific fields
                if (request.Role.Equals("Doctor", StringComparison.OrdinalIgnoreCase))
                {
                    if (string.IsNullOrWhiteSpace(request.Specialization))
                    {
                        return Ok(new LoginResponse { Success = false, Message = "Specialization is required for doctors" });
                    }
                    
                    if (string.IsNullOrWhiteSpace(request.LicenseNumber))
                    {
                        return Ok(new LoginResponse { Success = false, Message = "License number is required for doctors" });
                    }
                }
                
                // Check if email already exists
                if (DatabaseManager.GetInstance().EmailExists(request.Email))
                {
                    return Ok(new LoginResponse { Success = false, Message = "Email already registered" });
                }
                
                // Register the user
                var newUser = DatabaseManager.GetInstance().RegisterUser(request);
                
                if (newUser != null)
                {
                    // Don't send password back to client
                    newUser.Password = "";
                    
                    return Ok(new LoginResponse 
                    { 
                        Success = true, 
                        Message = "Registration successful", 
                        User = newUser 
                    });
                }
                else
                {
                    return Ok(new LoginResponse 
                    { 
                        Success = false, 
                        Message = "Registration failed" 
                    });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, new LoginResponse 
                { 
                    Success = false, 
                    Message = "Server error: " + ex.Message 
                });
            }
        }
    }
}
