using Microsoft.AspNetCore.Mvc;
using HealthTech.Services;

namespace HealthTech.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class WorkingTimeController : ControllerBase
    {
        [HttpGet("doctor/{doctorId}")]
        public ActionResult<List<WorkingTime>> GetDoctorWorkingTimes(int doctorId)
        {
            try
            {
                var workingTimes = DatabaseManager.GetInstance().GetDoctorWorkingTimes(doctorId);
                return Ok(workingTimes);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpPost]
        public ActionResult AddWorkingTime([FromBody] WorkingTime workingTime)
        {
            try
            {
                DatabaseManager.GetInstance().AddWorkingTime(workingTime);
                return Ok(new { message = "Working time added successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }
        
        [HttpPut("{id}")]
        public ActionResult UpdateWorkingTime(int id, [FromBody] WorkingTime workingTime)
        {
            try
            {
                workingTime.WorkingTimeID = id;
                DatabaseManager.GetInstance().UpdateWorkingTime(workingTime);
                return Ok(new { message = "Working time updated successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }
        
        [HttpDelete("{id}")]
        public ActionResult DeleteWorkingTime(int id)
        {
            try
            {
                DatabaseManager.GetInstance().DeleteWorkingTime(id);
                return Ok(new { message = "Working time deleted successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }
        
        [HttpPost("save-schedule")]
        public ActionResult SaveSchedule([FromBody] SaveScheduleRequest request)
        {
            try
            {
                // Delete existing working times for this doctor's weekly schedule
                foreach (var day in new[] { "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday" })
                {
                    DatabaseManager.GetInstance().DeleteDoctorWorkingTimesByDay(request.DoctorId, day, "working");
                }
                
                // Add new working times
                foreach (var wt in request.WorkingTimes)
                {
                    DatabaseManager.GetInstance().AddWorkingTime(wt);
                }
                
                return Ok(new { message = "Schedule saved successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }
        
        [HttpPost("save-leaves")]
        public ActionResult SaveLeaves([FromBody] SaveLeavesRequest request)
        {
            try
            {
                // Add each leave date as a separate record
                foreach (var leaveDate in request.LeaveDates)
                {
                    var workingTime = new WorkingTime
                    {
                        DoctorID = request.DoctorId,
                        StartTime = null,
                        EndTime = null,
                        Date = leaveDate,
                        Day = leaveDate.DayOfWeek.ToString(),
                        Type = "on leave"
                    };
                    DatabaseManager.GetInstance().AddWorkingTime(workingTime);
                }
                
                return Ok(new { message = "Leave dates saved successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }
        
        [HttpDelete("leave")]
        public ActionResult DeleteLeave([FromQuery] int doctorId, [FromQuery] string date)
        {
            try
            {
                var leaveDate = DateTime.Parse(date);
                var workingTimes = DatabaseManager.GetInstance().GetDoctorWorkingTimes(doctorId);
                var leaveRecord = workingTimes.FirstOrDefault(wt => 
                    wt.Type == "on leave" && 
                    wt.Date.HasValue && 
                    wt.Date.Value.Date == leaveDate.Date);
                
                if (leaveRecord != null)
                {
                    DatabaseManager.GetInstance().DeleteWorkingTime(leaveRecord.WorkingTimeID);
                    return Ok(new { message = "Leave date deleted successfully" });
                }
                
                return NotFound(new { message = "Leave record not found" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }
    }
    
    public class SaveScheduleRequest
    {
        public int DoctorId { get; set; }
        public List<WorkingTime> WorkingTimes { get; set; } = new();
    }
    
    public class SaveLeavesRequest
    {
        public int DoctorId { get; set; }
        public List<DateTime> LeaveDates { get; set; } = new();
    }
}
