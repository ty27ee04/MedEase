using Microsoft.AspNetCore.Mvc;
using HealthTech.Services;

namespace HealthTech.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class WorkingTimeController : ControllerBase
    {
        [HttpGet("doctor/{doctorId}")]
        public ActionResult<List<WorkingTime>> GetDoctorWorkingTimes(int doctorId)
        {
            try
            {
                var workingTimes = DatabaseManager.GetInstance().GetDoctorWorkingTimes(doctorId);
                return Ok(workingTimes);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpPost]
        public ActionResult AddWorkingTime([FromBody] WorkingTime workingTime)
        {
            try
            {
                DatabaseManager.GetInstance().AddWorkingTime(workingTime);
                return Ok(new { message = "Working time added successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }
    }
}
