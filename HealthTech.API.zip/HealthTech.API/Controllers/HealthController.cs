using Microsoft.AspNetCore.Mvc;

namespace HealthTech.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class HealthController : ControllerBase
    {
        [HttpGet]
        public IActionResult Check()
        {
            return Ok(new 
            { 
                status = "healthy",
                timestamp = DateTime.Now,
                message = "HealthTech API is running"
            });
        }
    }
}
