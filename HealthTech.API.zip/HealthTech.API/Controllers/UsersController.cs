using Microsoft.AspNetCore.Mvc;
using HealthTech.Services;
using System.Linq;

namespace HealthTech.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UsersController : ControllerBase
    {
        [HttpGet]
        public ActionResult<List<User>> GetAllUsers()
        {
            try
            {
                var users = DatabaseManager.GetInstance().GetUsersByRole("");
                // Get all users by combining all roles
                var allUsers = new List<User>();
                allUsers.AddRange(DatabaseManager.GetInstance().GetUsersByRole("Patient"));
                allUsers.AddRange(DatabaseManager.GetInstance().GetUsersByRole("Doctor"));
                allUsers.AddRange(DatabaseManager.GetInstance().GetUsersByRole("Receptionist"));
                return Ok(allUsers.Distinct().ToList());
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpGet("{id}")]
        public ActionResult<User> GetUserById(int id)
        {
            try
            {
                var user = DatabaseManager.GetInstance().GetUserById(id);
                if (user == null)
                    return NotFound();
                return Ok(user);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpGet("role/{role}")]
        public ActionResult<List<User>> GetUsersByRole(string role)
        {
            try
            {
                var users = DatabaseManager.GetInstance().GetUsersByRole(role);
                return Ok(users);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpPost("login")]
        public ActionResult<User> Login([FromBody] LoginRequest request)
        {
            try
            {
                var user = DatabaseManager.GetInstance().LoginUser(request.Username, request.Password);
                if (user == null)
                    return Unauthorized(new { message = "Invalid credentials" });
                return Ok(user);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpPost("login-by-name")]
        public ActionResult<User> LoginByName([FromBody] LoginByNameRequest request)
        {
            try
            {
                var user = DatabaseManager.GetInstance().LoginUser(request.Username, request.Password);
                if (user == null)
                    return Unauthorized(new { message = "Invalid credentials" });
                return Ok(user);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpPost("register")]
        public ActionResult<object> Register([FromBody] RegisterUserRequest request)
        {
            try
            {
                DatabaseManager.GetInstance().RegisterUser(
                    request.Name, request.Password, request.Role);
                // Get the user that was just created
                var user = DatabaseManager.GetInstance().LoginUser(request.Name, request.Password);
                return CreatedAtAction(nameof(GetUserById), new { id = user?.UserID ?? 0 }, new { id = user?.UserID ?? 0 });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpPost]
        public ActionResult<object> CreateUser([FromBody] CreateUserRequest request)
        {
            try
            {
                DatabaseManager.GetInstance().RegisterUser(
                    request.Name, request.Password, request.Role);
                var user = DatabaseManager.GetInstance().LoginUser(request.Name, request.Password);
                return CreatedAtAction(nameof(GetUserById), new { id = user?.UserID ?? 0 }, new { id = user?.UserID ?? 0 });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpPost("register-patient")]
        public ActionResult<object> RegisterPatient([FromBody] RegisterPatientRequest request)
        {
            try
            {
                var id = DatabaseManager.GetInstance().RegisterPatient(
                    request.Name, request.Email, request.Password, 
                    request.Phone, request.Age, request.Gender);
                return CreatedAtAction(nameof(GetUserById), new { id }, new { id });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }
    }

    public class LoginRequest
    {
        public string Username { get; set; } = "";
        public string Password { get; set; } = "";
    }

    public class LoginByNameRequest
    {
        public string Username { get; set; } = "";
        public string Password { get; set; } = "";
    }

    public class RegisterUserRequest
    {
        public string Name { get; set; } = "";
        public string Password { get; set; } = "";
        public string Role { get; set; } = "";
    }

    public class CreateUserRequest
    {
        public string Name { get; set; } = "";
        public string Username { get; set; } = "";
        public string Password { get; set; } = "";
        public string Role { get; set; } = "";
    }

    public class RegisterPatientRequest
    {
        public string Name { get; set; } = "";
        public string Email { get; set; } = "";
        public string Password { get; set; } = "";
        public string Phone { get; set; } = "";
        public int? Age { get; set; }
        public string Gender { get; set; } = "";
    }
}
