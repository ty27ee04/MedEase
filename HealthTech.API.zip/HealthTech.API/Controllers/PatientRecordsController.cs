using Microsoft.AspNetCore.Mvc;
using HealthTech.Services;
using System.Linq;

namespace HealthTech.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PatientRecordsController : ControllerBase
    {
        [HttpGet("patient/{patientId}")]
        public ActionResult<List<RecordModel>> GetRecordsByPatient(int patientId)
        {
            try
            {
                var records = DatabaseManager.GetInstance().GetPatientRecords(patientId);
                Console.WriteLine($"[API] GetRecordsByPatient({patientId}) - Retrieved {records.Count} records");
                foreach (var rec in records.Take(3))
                {
                    Console.WriteLine($"  - RecordID: {rec.RecordID}, Title: {rec.Title}, InFolder: {rec.InFolder}, FolderName: {rec.FolderName}");
                }
                return Ok(records);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpGet("patient/{patientId}/root")]
        public ActionResult<List<RecordModel>> GetRootRecords(int patientId)
        {
            try
            {
                var allRecords = DatabaseManager.GetInstance().GetPatientRecords(patientId);
                var rootRecords = allRecords.Where(r => r.ParentFolderID == null).ToList();
                return Ok(rootRecords);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpGet("folder/{folderId}/children")]
        public ActionResult<List<RecordModel>> GetChildRecords(int folderId)
        {
            try
            {
                // Get patient ID from the folder record first
                var allRecords = DatabaseManager.GetInstance().GetPatientRecords(0); // Need to get all or specific patient
                var childRecords = allRecords.Where(r => r.ParentFolderID == folderId).ToList();
                return Ok(childRecords);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpGet("{id}")]
        public ActionResult<RecordModel> GetRecordById(int id)
        {
            try
            {
                // We need to get all records and filter - not ideal but works with current structure
                var allRecords = DatabaseManager.GetInstance().GetPatientRecords(0); // This won't work well
                var record = allRecords.FirstOrDefault(r => r.RecordID == id);
                if (record == null)
                    return NotFound();
                return Ok(record);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpPost]
        public ActionResult<object> CreateRecord([FromBody] RecordModel record)
        {
            try
            {
                Console.WriteLine($"[API] CreateRecord - PatientID: {record.PatientID}, Title: {record.Title}, Type: {record.RecordType}, InFolder: {record.InFolder}, FolderName: {record.FolderName}");
                DatabaseManager.GetInstance().AddPatientRecord(record);
                Console.WriteLine($"[API] Record created successfully with ID: {record.RecordID}");
                return Ok(new { id = record.RecordID, message = "Record added successfully" });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[API] Error creating record: {ex.Message}");
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpPut("{id}")]
        public ActionResult UpdateRecord(int id, [FromBody] RecordModel record)
        {
            try
            {
                record.RecordID = id;
                DatabaseManager.GetInstance().UpdatePatientRecord(record);
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpDelete("{id}")]
        public ActionResult DeleteRecord(int id)
        {
            try
            {
                DatabaseManager.GetInstance().DeletePatientRecord(id);
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }
    }
}
