using Microsoft.AspNetCore.Mvc;
using HealthTech.Services;

namespace HealthTech.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RoomsController : ControllerBase
    {
        [HttpGet]
        public ActionResult<List<Room>> GetAllRooms()
        {
            try
            {
                var rooms = DatabaseManager.GetInstance().GetRooms();
                return Ok(rooms);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpGet("{id}")]
        public ActionResult<Room> GetRoomById(int id)
        {
            try
            {
                var rooms = DatabaseManager.GetInstance().GetRooms();
                var room = rooms.FirstOrDefault(r => r.RoomID == id);
                if (room == null)
                    return NotFound();
                return Ok(room);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }
    }
}
