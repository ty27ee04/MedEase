using Microsoft.AspNetCore.Mvc;
using HealthTech.Services;

namespace HealthTech.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RoomsController : ControllerBase
    {
        [HttpGet]
        public ActionResult<List<Room>> GetAllRooms()
        {
            try
            {
                var rooms = DatabaseManager.GetInstance().GetRooms();
                return Ok(rooms);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpGet("{id}")]
        public ActionResult<Room> GetRoomById(int id)
        {
            try
            {
                var rooms = DatabaseManager.GetInstance().GetRooms();
                var room = rooms.FirstOrDefault(r => r.RoomID == id);
                if (room == null)
                    return NotFound();
                return Ok(room);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }
        
        [HttpPost]
        public ActionResult<Room> CreateRoom([FromBody] Room room)
        {
            try
            {
                DatabaseManager.GetInstance().AddRoom(room);
                return Ok(new { id = room.RoomID, message = "Room created successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }
        
        [HttpPut("{id}")]
        public ActionResult UpdateRoom(int id, [FromBody] Room room)
        {
            try
            {
                room.RoomID = id;
                DatabaseManager.GetInstance().UpdateRoom(room);
                return Ok(new { message = "Room updated successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }
        
        [HttpDelete("{id}")]
        public ActionResult DeleteRoom(int id)
        {
            try
            {
                DatabaseManager.GetInstance().DeleteRoom(id);
                return Ok(new { message = "Room deleted successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }
        
        [HttpGet("available")]
        public ActionResult<bool> CheckRoomAvailability([FromQuery] int roomId, [FromQuery] DateTime dateTime)
        {
            try
            {
                bool isAvailable = DatabaseManager.GetInstance().IsRoomAvailable(roomId, dateTime);
                return Ok(new { roomId, dateTime, isAvailable });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }
    }
}
